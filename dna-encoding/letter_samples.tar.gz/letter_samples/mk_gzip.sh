#!/bin/bash

mkdir -p gzip && cp *.bmp gzip && gzip -f gzip/*.bmp && ls -lS gzip
