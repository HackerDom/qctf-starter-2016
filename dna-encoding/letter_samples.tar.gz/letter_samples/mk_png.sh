#!/bin/bash

mkdir -p png && cp *.bmp png && mogrify -format png png/*.bmp && rm -f png/*.bmp && ls -lS png
